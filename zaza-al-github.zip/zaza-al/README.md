# 🌟 Zaza Al — مساعدك الذكي للدردشة

موقع دردشة ذكاء اصطناعي عربي عصري مبني على **Next.js 16** و **TypeScript** و **Tailwind CSS 4** و **shadcn/ui**، يعمل مثل ChatGPT تمامًا — يجيب عن الأسئلة، يحكي النكات، يكتب الأكواد، ويشرح المفاهيم.

> 🤖 مدعوم بواسطة نموذج GLM-4-Plus عبر `z-ai-web-dev-sdk`.

---

## ✨ الميزات الرئيسية

| الميزة | الوصف |
|--------|--------|
| 🌊 **ردود متدفقة** | يظهر النص كلمة بكلمة لحظيًا (SSE streaming) |
| 🎨 **تصميم عصري RTL** | واجهة عربية كاملة بخط Cairo وألوان بنفسجي/فيروزي |
| 🌗 **وضع ليلي/نهاري** | تبديل فوري بين السمتين مع حفظ التفضيل |
| 💬 **دعم Markdown كامل** | عناوين، قوائم، جداول، اقتباسات، وكتل أكواد ملوّنة |
| 📋 **نسخ الأكواد** | زر نسخ على كل كتلة كود مع تمييز الصياغة (Prism) |
| 🗂️ **محادثة متعددة الأدوار** | يتذكر سياق الحوار السابق (حتى 30 رسالة) |
| 💾 **حفظ تلقائي** | المحادثة تبقى محفوظة في `localStorage` بعد إعادة التحميل |
| 📱 **متجاوب بالكامل** | قائمة جانبية على الجوال، تخطيط مريح على سطح المكتب |
| ⏹️ **إيقاف الرد** | زر لإيقاف التدفق في أي وقت |
| 🔔 **إشعارات أنيقة** | عبر مكتبة Sonner |
| ⌨️ **اختصارات لوحة المفاتيح** | Enter للإرسال، Shift+Enter لسطر جديد |
| 🎯 **شاشة ترحيب** | 4 أمثلة جاهزة للبدء السريع |

---

## 🛠️ التقنيات المستخدمة

- **Framework**: [Next.js 16](https://nextjs.org/) مع App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 + [shadcn/ui](https://ui.shadcn.com/) (New York style)
- **UI Components**: Radix UI primitives + Lucide icons
- **Markdown**: react-markdown + react-syntax-highlighter
- **Theming**: next-themes (light/dark mode)
- **Toasts**: Sonner
- **Animations**: Framer Motion + Tailwind animations
- **AI SDK**: z-ai-web-dev-sdk (GLM-4-Plus model)
- **Fonts**: Cairo (عربي) + Geist (لاتيني)

---

## 📁 هيكل المشروع

```
zaza-al/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   └── chat/
│   │   │       └── route.ts        # واجهة برمجة الدردشة (SSE streaming)
│   │   ├── globals.css             # الأنماط العامة + سمات Zaza Al
│   │   ├── layout.tsx              # التخطيط الرئيسي + دعم RTL + خط Cairo
│   │   └── page.tsx                # صفحة الدردشة الرئيسية
│   ├── components/
│   │   ├── theme-provider.tsx      # موفر السمة (next-themes)
│   │   ├── zaza/
│   │   │   ├── logo.tsx            # شعار Zaza Al (SVG متحرك)
│   │   │   └── markdown.tsx        # عارض Markdown مع تمييز الأكواد
│   │   └── ui/                     # مكونات shadcn/ui
│   └── lib/
│       └── utils.ts                # أدوات مساعدة (cn, etc.)
├── public/
│   ├── logo.svg
│   └── robots.txt
├── prisma/
│   └── schema.prisma               # مخطط قاعدة البيانات (اختياري)
├── package.json
├── tsconfig.json
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.mjs
├── eslint.config.mjs
├── components.json
└── README.md
```

---

## 🚀 التشغيل محليًا

### المتطلبات
- [Node.js](https://nodejs.org/) 18.17 أو أحدث
- [Bun](https://bun.sh/) (مُوصى به) أو npm/yarn/pnpm

### الخطوات

1. **تثبيت الحزم:**
   ```bash
   bun install
   # أو: npm install
   ```

2. **إعداد مفاتيح Z.ai SDK:**

   أنشئ ملف `.z-ai-config` في المجلد الرئيسي للمستخدم (`~/.z-ai-config`) أو في جذر المشروع:

   ```json
   {
     "baseUrl": "https://api.z.ai/api/paas/v4",
     "apiKey": "YOUR_API_KEY_HERE"
   }
   ```

   > احصل على مفتاح API من [Z.ai](https://z.ai/).

3. **تشغيل خادم التطوير:**
   ```bash
   bun run dev
   # أو: npm run dev
   ```

4. **افتح المتصفح على:**
   ```
   http://localhost:3000
   ```

### بناء الإنتاج

```bash
bun run build
bun run start
```

---

## 🎨 التخصيص

### تغيير الألوان

عدّل المتغيرات في `src/app/globals.css`:

```css
:root {
  --primary: oklch(0.55 0.22 295);    /* اللون الأساسي - بنفسجي */
  --accent: oklch(0.7 0.18 165);      /* اللون المميز - فيروزي */
  /* ... */
}
```

### تغيير شخصية المساعد

عدّل `ZAZA_SYSTEM_PROMPT` في `src/app/api/chat/route.ts` لتغيير سلوك المساعد وأسلوبه.

### تغيير الأمثلة الافتراضية

عدّل مصفوفة `EXAMPLE_PROMPTS` في `src/app/page.tsx`.

---

## 📦 الرفع على GitHub

1. أنشئ مستودعًا جديدًا على [GitHub](https://github.com/new).
2. فك ضغط ملف ZIP هذا.
3. في المجلد الناتج، نفّذ:

```bash
git init
git add .
git commit -m "🎉 Initial commit: Zaza Al AI chat app"
git branch -M main
git remote add origin https://github.com/USERNAME/zaza-al.git
git push -u origin main
```

---

## 🌐 النشر

### Vercel (الأسهل)

1. ارفع المشروع على GitHub.
2. اذهب إلى [vercel.com/new](https://vercel.com/new).
3. اختر المستودع وانقر Deploy.

### أي استضافة Node.js

```bash
bun run build
bun run start
```

تأكد من إعداد متغيرات البيئة اللازمة على منصة الاستضافة.

---

## 📝 الترخيص

 ISC — استخدمه بحرية لأي مشروع شخصي أو تجاري.

---

## 🙏 شكر خاص

- [Z.ai](https://z.ai/) — لتوفير نموذج GLM-4-Plus.
- [shadcn/ui](https://ui.shadcn.com/) — لمكونات الواجهة الجميلة.
- [Next.js](https://nextjs.org/) — للإطار الرائع.

---

صُنع بـ ❤️ لمجتمع المطورين العرب.
