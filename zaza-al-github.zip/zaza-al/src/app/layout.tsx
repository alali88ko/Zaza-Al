import type { Metadata } from "next";
import { Geist, Geist_Mono, Cairo } from "next/font/google";
import "./globals.css";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Zaza Al — مساعدك الذكي",
  description:
    "Zaza Al هو مساعد ذكاء اصطناعي عربي متطور يجيب عن أسئلتك، يمازحك، ويساعدك في كل شيء — تمامًا مثل النماذج الرائدة.",
  keywords: [
    "Zaza Al",
    "ذكاء اصطناعي",
    "مساعد ذكي",
    "دردشة",
    "AI",
    "ChatGPT",
    "عربي",
  ],
  authors: [{ name: "Zaza Al" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Zaza Al — مساعدك الذكي",
    description:
      "دردشة ذكية مع Zaza Al — يجيب عن الأسئلة والمزاح وكل شيء.",
    siteName: "Zaza Al",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Zaza Al",
    description: "مساعدك الذكي للدردشة والمزاح والأسئلة.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${cairo.variable} antialiased bg-background text-foreground font-cairo`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <SonnerToaster position="top-center" richColors closeButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
