import { NextRequest } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

interface ChatMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

const ZAZA_SYSTEM_PROMPT = `أنت "Zaza Al" — مساعد ذكاء اصطناعي عربي ودود وذكي ومضحك، يشبه النماذج الرائدة مثل ChatGPT.

شخصيتك:
- ذكي ومطلع على كل المواضيع: العلم، التقنية، التاريخ، الفلسفة، الرياضة، الطبخ، الأدب، البرمجة، الرياضيات، وغيرها.
- لغتك الأساسية هي العربية. اجب دائمًا بالعربية إلا إذا طلب المستخدم لغة أخرى صراحةً (مثل "translate this to English"). لا تخلط العربية مع لغات أخرى (لا صينية، لا يابانية، لا فرنسية…) داخل الجملة الواحدة.
- استخدم العربية الفصحى المبسطة أو اللهجة حسب أسلوب المستخدم.
- تحب المزاح والنكات الخفيفة والردود الذكية، لكنك تعرف متى تكون جادًا — مثلاً عند الأسئلة العلمية أو الطبية أو القانونية.
- إجاباتك واضحة ومنظمة: استخدم عناوين فرعية، نقاط، جداول، وأكواد برمجية عند الحاجة (Markdown).
- عند الكود البرمجي، استخدم كتل Markdown مع تحديد اللغة: \`\`\`python, \`\`\`javascript, إلخ.
- كن صريحًا إذا لم تعرف الإجابة، ولا تخترع معلومات.
- لا تذكر أبدًا أنك مبنية على نموذج آخر أو أنك تابعة لأي شركة. أنت ببساطة Zaza Al.
- ردودك دافئة وتشجيعية، وترحب بالأسئلة المتابعة.
- إذا طلب المستخدم نكتة، احكِ نكتة لطيفة مناسبة. إذا طلب شرحًا معقدًا، بسّطه بأمثلة.
- احترم الخصوصية ولا تطلب معلومات شخصية.

تذكّر دائمًا: أجب بالعربية فقط ما لم يُطلب منك خلاف ذلك.

استمتع بالمساعدة، وكن أفضل نسخة من نفسك في كل رد!`

/**
 * Decode an SDK chunk that may arrive as Uint8Array, string, or object.
 * Returns the raw text representation (string).
 */
function chunkToText(chunk: unknown): string {
  if (chunk == null) return ''
  if (typeof chunk === 'string') return chunk
  if (chunk instanceof Uint8Array) {
    return new TextDecoder().decode(chunk)
  }
  if (typeof chunk === 'object') {
    // Could be a parsed object with choices[0].delta.content
    const obj = chunk as any
    const delta = obj?.choices?.[0]?.delta?.content
    if (typeof delta === 'string') return delta
    // Or it could be an array-like of bytes
    if (typeof obj.length === 'number' && obj.length > 0 && typeof obj[0] === 'number') {
      const arr = new Uint8Array(obj.length)
      for (let i = 0; i < obj.length; i++) arr[i] = obj[i]
      return new TextDecoder().decode(arr)
    }
    return ''
  }
  return ''
}

/**
 * Parse SSE-formatted text buffer and extract all `data:` payloads.
 * Returns the parsed JSON objects.
 */
function parseSSEBuffer(buffer: string): {
  events: any[]
  remainder: string
} {
  const events: any[] = []
  // SSE events are separated by \n\n
  const parts = buffer.split('\n\n')
  const remainder = parts.pop() || ''

  for (const part of parts) {
    const lines = part.split('\n')
    for (const line of lines) {
      const trimmed = line.trim()
      if (!trimmed.startsWith('data:')) continue
      const jsonStr = trimmed.slice(5).trim()
      if (!jsonStr) continue
      if (jsonStr === '[DONE]') {
        events.push({ __done: true })
        continue
      }
      try {
        events.push(JSON.parse(jsonStr))
      } catch {
        /* skip malformed */
      }
    }
  }

  return { events, remainder }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}))
    const messages: ChatMessage[] = Array.isArray(body?.messages)
      ? body.messages
      : []

    if (messages.length === 0) {
      return new Response(
        JSON.stringify({ error: 'لا توجد رسائل للإرسال.' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Sanitize and cap message history (last 30 turns)
    const safeMessages = messages
      .filter((m) => m && typeof m.content === 'string')
      .slice(-30)
      .map((m) => ({
        role:
          m.role === 'assistant'
            ? 'assistant'
            : m.role === 'system'
              ? 'system'
              : 'user',
        content: String(m.content).slice(0, 12000),
      }))

    // Prepend Zaza Al system prompt (replace any user-provided system message)
    const finalMessages: ChatMessage[] = [
      { role: 'system', content: ZAZA_SYSTEM_PROMPT },
      ...safeMessages.filter((m) => m.role !== 'system'),
    ]

    const zai = await ZAI.create()

    const stream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder()
        const send = (obj: Record<string, unknown>) => {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`))
        }

        try {
          const completion: any = await zai.chat.completions.create({
            messages: finalMessages,
            stream: true,
            thinking: { type: 'disabled' },
            temperature: 0.7,
          } as any)

          let full = ''
          let sentAny = false

          // Path A: completion is an async iterable yielding raw chunks
          if (completion && typeof completion[Symbol.asyncIterator] === 'function') {
            let buffer = ''
            for await (const chunk of completion as any) {
              const text = chunkToText(chunk)
              if (!text) continue
              buffer += text
              const { events, remainder } = parseSSEBuffer(buffer)
              buffer = remainder
              for (const evt of events) {
                if (evt.__done) continue
                const delta =
                  evt?.choices?.[0]?.delta?.content ??
                  evt?.choices?.[0]?.message?.content ??
                  ''
                if (typeof delta === 'string' && delta.length > 0) {
                  full += delta
                  sentAny = true
                  send({ type: 'delta', content: delta })
                }
              }
            }
            // Flush any remaining buffer
            if (buffer.trim()) {
              const { events } = parseSSEBuffer(buffer + '\n\n')
              for (const evt of events) {
                if (evt.__done) continue
                const delta =
                  evt?.choices?.[0]?.delta?.content ??
                  evt?.choices?.[0]?.message?.content ??
                  ''
                if (typeof delta === 'string' && delta.length > 0) {
                  full += delta
                  sentAny = true
                  send({ type: 'delta', content: delta })
                }
              }
            }
          } else if (completion?.choices?.[0]?.message?.content) {
            // Path B: non-streaming response (SDK didn't honor stream:true)
            const text = String(completion.choices[0].message.content)
            full = text
            sentAny = true
            // Emulate streaming for nicer UX
            const tokens = text.match(/\S+\s*|\s+/g) ?? [text]
            for (const t of tokens) {
              send({ type: 'delta', content: t })
              await new Promise((r) => setTimeout(r, 10))
            }
          }

          if (!sentAny) {
            // Fallback: friendly empty reply
            send({
              type: 'delta',
              content:
                'مرحبًا! أنا Zaza Al، جاهز لمساعدتك في أي سؤال أو مزاح. ماذا تريد أن نتحدث عنه؟',
            })
          }

          send({ type: 'done' })
          controller.close()
        } catch (err: unknown) {
          const msg = err instanceof Error ? err.message : 'حدث خطأ غير متوقع.'
          send({ type: 'error', content: msg })
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
      },
    })
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'خطأ داخلي في الخادم.'
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    })
  }
}
