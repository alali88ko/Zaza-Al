'use client'

import * as React from 'react'
import { useTheme } from 'next-themes'
import {
  Moon,
  Sun,
  Send,
  Square,
  Trash2,
  Sparkles,
  MessageCircle,
  Code2,
  Laugh,
  GraduationCap,
  Lightbulb,
  Heart,
  Loader2,
  Menu,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ZazaLogo } from '@/components/zaza/logo'
import { ZazaMarkdown } from '@/components/zaza/markdown'
import { toast } from 'sonner'

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

type Role = 'user' | 'assistant'

interface ChatMessage {
  id: string
  role: Role
  content: string
  createdAt: number
  streaming?: boolean
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const STORAGE_KEY = 'zaza-al-conversation-v1'

const EXAMPLE_PROMPTS = [
  {
    icon: Laugh,
    title: 'احكِ لي نكتة',
    prompt: 'احكِ لي نكتة عربية مضحكة قصيرة',
    color: 'from-amber-500/20 to-rose-500/20',
    iconColor: 'text-amber-500',
  },
  {
    icon: Code2,
    title: 'اكتب لي كود',
    prompt: 'اكتب لي دالة بلغة Python تحسب متوسط قائمة أرقام مع شرح',
    color: 'from-emerald-500/20 to-teal-500/20',
    iconColor: 'text-emerald-500',
  },
  {
    icon: GraduationCap,
    title: 'اشرح لي مفهوم',
    prompt: 'اشرح لي نظرية النسبية لأينشتاين بطريقة مبسطة',
    color: 'from-violet-500/20 to-fuchsia-500/20',
    iconColor: 'text-violet-500',
  },
  {
    icon: Lightbulb,
    title: 'اقترح أفكارًا',
    prompt: 'اقترح عليّ 5 أفكار لمشروع جانبي يمكنني العمل عليه في عطلة الأسبوع',
    color: 'from-rose-500/20 to-pink-500/20',
    iconColor: 'text-rose-500',
  },
]

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

function loadConversation(): ChatMessage[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed
      .filter((m) => m && m.id && m.role && typeof m.content === 'string')
      .map((m) => ({ ...m, streaming: false }))
  } catch {
    return []
  }
}

function saveConversation(messages: ChatMessage[]) {
  if (typeof window === 'undefined') return
  try {
    const toSave = messages.filter(
      (m) => m.role === 'user' || m.content.trim().length > 0
    )
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(
        toSave.map((m) => ({
          id: m.id,
          role: m.role,
          content: m.content,
          createdAt: m.createdAt,
        }))
      )
    )
  } catch {
    /* ignore quota errors */
  }
}

/* ------------------------------------------------------------------ */
/* Streaming chat hook                                                 */
/* ------------------------------------------------------------------ */

function useChatStream() {
  const abortRef = React.useRef<AbortController | null>(null)

  const stop = React.useCallback(() => {
    abortRef.current?.abort()
    abortRef.current = null
  }, [])

  const send = React.useCallback(
    async (
      messages: ChatMessage[],
      onDelta: (fullText: string) => void,
      onDone: () => void,
      onError: (err: string) => void
    ) => {
      const controller = new AbortController()
      abortRef.current = controller

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: messages.map((m) => ({
              role: m.role,
              content: m.content,
            })),
          }),
          signal: controller.signal,
        })

        if (!res.ok) {
          const txt = await res.text().catch(() => 'فشل الاتصال بالخادم.')
          onError(txt)
          return
        }

        if (!res.body) {
          onError('استجابة فارغة من الخادم.')
          return
        }

        const reader = res.body.getReader()
        const decoder = new TextDecoder()
        let buffer = ''
        let full = ''

        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          buffer += decoder.decode(value, { stream: true })
          const lines = buffer.split('\n')
          // Keep the last partial line in buffer
          buffer = lines.pop() || ''
          for (const line of lines) {
            const trimmed = line.trim()
            if (!trimmed || !trimmed.startsWith('data:')) continue
            const jsonStr = trimmed.slice(5).trim()
            if (!jsonStr) continue
            try {
              const obj = JSON.parse(jsonStr)
              if (obj.type === 'delta' && typeof obj.content === 'string') {
                full += obj.content
                onDelta(full)
              } else if (obj.type === 'error') {
                onError(String(obj.content || 'خطأ غير معروف.'))
                return
              } else if (obj.type === 'done') {
                onDone()
                return
              }
            } catch {
              /* skip malformed line */
            }
          }
        }
        // If we exit the loop without explicit done, mark done anyway
        onDone()
      } catch (err: unknown) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          onDone()
          return
        }
        const msg = err instanceof Error ? err.message : 'فشل الاتصال.'
        onError(msg)
      } finally {
        abortRef.current = null
      }
    },
    []
  )

  return { send, stop }
}

/* ------------------------------------------------------------------ */
/* Auto-resize textarea hook                                          */
/* ------------------------------------------------------------------ */

function useAutoResize(value: string, max = 200) {
  const ref = React.useRef<HTMLTextAreaElement>(null)
  React.useEffect(() => {
    const el = ref.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.min(el.scrollHeight, max)}px`
  }, [value, max])
  return ref
}

/* ------------------------------------------------------------------ */
/* Typing indicator                                                    */
/* ------------------------------------------------------------------ */

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-1 py-2">
      <span className="zaza-typing-dot size-2 rounded-full bg-primary/60" />
      <span className="zaza-typing-dot size-2 rounded-full bg-primary/60" />
      <span className="zaza-typing-dot size-2 rounded-full bg-primary/60" />
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Message bubble                                                      */
/* ------------------------------------------------------------------ */

interface BubbleProps {
  message: ChatMessage
}

function MessageBubble({ message }: BubbleProps) {
  const isUser = message.role === 'user'
  const showTyping =
    !isUser && message.streaming && message.content.length === 0
  const showFallback =
    !isUser && !message.streaming && message.content.trim().length === 0

  return (
    <div
      className={cn(
        'zaza-msg-in flex gap-3 px-3 sm:px-5',
        isUser ? 'flex-row-reverse' : 'flex-row'
      )}
    >
      {/* Avatar */}
      <div
        className={cn(
          'flex-shrink-0 size-9 rounded-full grid place-items-center overflow-hidden',
          isUser
            ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white'
            : 'bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500 text-white zaza-avatar-pulse'
        )}
      >
        {isUser ? (
          <span className="text-sm font-bold">أنت</span>
        ) : (
          <ZazaLogo size={28} />
        )}
      </div>

      {/* Bubble */}
      <div
        className={cn(
          'flex flex-col max-w-[85%] sm:max-w-[78%]',
          isUser ? 'items-end' : 'items-start'
        )}
      >
        <div
          className={cn(
            'rounded-2xl px-4 py-2.5 shadow-sm border',
            isUser
              ? 'bg-primary text-primary-foreground border-transparent rounded-tr-sm'
              : 'bg-card text-card-foreground border-border rounded-tl-sm'
          )}
        >
          {showTyping ? (
            <TypingIndicator />
          ) : showFallback ? (
            <p className="text-sm text-muted-foreground italic">
              لم أتلقَّ ردًا. حاول مرة أخرى من فضلك.
            </p>
          ) : isUser ? (
            <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
              {message.content}
            </p>
          ) : (
            <div className={cn('text-[15px]', message.streaming && 'zaza-caret')}>
              <ZazaMarkdown content={message.content} />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Welcome screen                                                      */
/* ------------------------------------------------------------------ */

function WelcomeScreen({
  onPick,
}: {
  onPick: (prompt: string) => void
}) {
  return (
    <div className="flex flex-col items-center justify-center min-h-full px-5 py-10 text-center">
      <div className="relative mb-6">
        <div className="absolute inset-0 -m-8 bg-gradient-to-br from-violet-500/30 to-teal-500/30 blur-3xl rounded-full" />
        <div className="relative">
          <ZazaLogo size={88} />
        </div>
      </div>

      <h1 className="text-3xl sm:text-4xl font-extrabold mb-2 tracking-tight">
        <span className="zaza-gradient-text">Zaza Al</span>
      </h1>
      <p className="text-muted-foreground max-w-md mb-8 leading-relaxed">
        مساعدك الذكي للدردشة والمزاح والإجابة عن كل أسئلتك — تمامًا مثل النماذج
        الرائدة. جرّب أحد الاقتراحات أو اكتب أي شيء يدور في ذهنك!
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl">
        {EXAMPLE_PROMPTS.map((p) => {
          const Icon = p.icon
          return (
            <button
              key={p.title}
              onClick={() => onPick(p.prompt)}
              className={cn(
                'group relative overflow-hidden text-right p-4 rounded-xl border border-border bg-card/50 hover:bg-card hover:border-primary/40 transition-all',
                'flex items-center gap-3'
              )}
            >
              <div
                className={cn(
                  'size-10 rounded-lg grid place-items-center bg-gradient-to-br',
                  p.color
                )}
              >
                <Icon className={cn('size-5', p.iconColor)} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm mb-0.5">{p.title}</div>
                <div className="text-xs text-muted-foreground line-clamp-1">
                  {p.prompt}
                </div>
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Mobile sidebar drawer                                              */
/* ------------------------------------------------------------------ */

interface SidebarContentProps {
  onNewChat: () => void
  messageCount: number
  lastUpdate?: number
}

function SidebarContent({ onNewChat, messageCount }: SidebarContentProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="p-4">
        <Button
          onClick={onNewChat}
          className="w-full justify-start gap-2"
          variant="default"
        >
          <MessageCircle className="size-4" />
          محادثة جديدة
        </Button>
      </div>

      <div className="px-4 pb-4">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-1">
          الإحصائيات
        </div>
        <div className="rounded-lg border border-border bg-card/50 p-3 space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">عدد الرسائل</span>
            <span className="font-semibold">{messageCount}</span>
          </div>
        </div>
      </div>

      <div className="mt-auto p-4 border-t border-border">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Sparkles className="size-3.5" />
          <span>مدعوم بواسطة Zaza Al AI</span>
        </div>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Main page                                                           */
/* ------------------------------------------------------------------ */

export default function Home() {
  const [messages, setMessages] = React.useState<ChatMessage[]>([])
  const [input, setInput] = React.useState('')
  const [busy, setBusy] = React.useState(false)
  const [sidebarOpen, setSidebarOpen] = React.useState(false)
  const [hydrated, setHydrated] = React.useState(false)

  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  const scrollRef = React.useRef<HTMLDivElement>(null)
  const bottomRef = React.useRef<HTMLDivElement>(null)
  const taRef = useAutoResize(input)

  const { send, stop } = useChatStream()

  /* Hydration */
  React.useEffect(() => {
    setMessages(loadConversation())
    setHydrated(true)
    setMounted(true)
  }, [])

  /* Persist */
  React.useEffect(() => {
    if (hydrated) saveConversation(messages)
  }, [messages, hydrated])

  /* Auto-scroll */
  React.useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages])

  /* ----------------------------------------------------------------
   * Send a user message + stream assistant reply
   * ---------------------------------------------------------------- */
  const submit = React.useCallback(
    async (text: string) => {
      const trimmed = text.trim()
      if (!trimmed || busy) return

      const userMsg: ChatMessage = {
        id: uid(),
        role: 'user',
        content: trimmed,
        createdAt: Date.now(),
      }

      const assistantMsg: ChatMessage = {
        id: uid(),
        role: 'assistant',
        content: '',
        createdAt: Date.now(),
        streaming: true,
      }

      const history = [...messages, userMsg]
      setMessages([...history, assistantMsg])
      setInput('')
      setBusy(true)

      await send(
        history,
        (full) => {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMsg.id ? { ...m, content: full, streaming: true } : m
            )
          )
        },
        () => {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMsg.id ? { ...m, streaming: false } : m
            )
          )
          setBusy(false)
        },
        (err) => {
          setMessages((prev) =>
            prev
              .map((m) =>
                m.id === assistantMsg.id
                  ? {
                      ...m,
                      streaming: false,
                      content:
                        m.content ||
                        `⚠️ حدث خطأ أثناء الرد: ${err}\n\nحاول مرة أخرى.`,
                    }
                  : m
              )
              .filter((m) => m.content.length > 0 || m.role !== 'assistant' || m.id !== assistantMsg.id)
          )
          setBusy(false)
          toast.error('تعذّر الحصول على رد من Zaza Al.', {
            description: err,
          })
        }
      )
    },
    [busy, messages, send]
  )

  /* ----------------------------------------------------------------
   * Handlers
   * ---------------------------------------------------------------- */
  const onKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault()
      submit(input)
    }
  }

  const onNewChat = () => {
    if (busy) stop()
    setMessages([])
    setInput('')
    setSidebarOpen(false)
    try {
      window.localStorage.removeItem(STORAGE_KEY)
    } catch {
      /* ignore */
    }
    toast.success('بدأت محادثة جديدة.')
  }

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark')
  }

  const hasMessages = messages.length > 0

  /* ----------------------------------------------------------------
   * Render
   * ---------------------------------------------------------------- */
  return (
    <div className="relative flex h-screen w-full overflow-hidden bg-background">
      {/* Decorative background blobs */}
      <div className="zaza-bg-blob bg-violet-500 size-[28rem] -top-32 -right-32" />
      <div className="zaza-bg-blob bg-teal-500 size-[32rem] -bottom-40 -left-40" style={{ animationDelay: '4s' }} />
      <div className="zaza-bg-blob bg-fuchsia-500 size-[24rem] top-1/3 right-1/4 opacity-20" style={{ animationDelay: '8s' }} />

      {/* Sidebar — desktop */}
      <aside className="hidden md:flex w-64 flex-shrink-0 border-l border-border bg-sidebar/50 backdrop-blur-sm relative z-10">
        <SidebarContent onNewChat={onNewChat} messageCount={messages.length} />
      </aside>

      {/* Sidebar — mobile drawer */}
      {sidebarOpen && (
        <div className="md:hidden fixed inset-0 z-50">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="absolute inset-y-0 right-0 w-72 bg-sidebar border-l border-border shadow-xl zaza-msg-in">
            <div className="flex items-center justify-between p-3 border-b border-border">
              <span className="font-semibold">القائمة</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarOpen(false)}
                className="size-8"
              >
                <X className="size-4" />
              </Button>
            </div>
            <SidebarContent
              onNewChat={() => {
                onNewChat()
                setSidebarOpen(false)
              }}
              messageCount={messages.length}
            />
          </aside>
        </div>
      )}

      {/* Main chat area */}
      <div className="relative z-10 flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="flex items-center gap-3 px-3 sm:px-5 py-3 border-b border-border bg-background/80 backdrop-blur-md sticky top-0 z-20">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setSidebarOpen(true)}
            aria-label="فتح القائمة"
          >
            <Menu className="size-5" />
          </Button>

          <div className="flex items-center gap-2.5 flex-1 min-w-0">
            <div className="md:hidden">
              <ZazaLogo size={32} />
            </div>
            <div className="min-w-0">
              <h1 className="font-bold text-base sm:text-lg leading-tight truncate">
                <span className="zaza-gradient-text">Zaza Al</span>
              </h1>
              <p className="text-[11px] text-muted-foreground leading-tight flex items-center gap-1.5">
                <span className="relative flex size-2">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75 animate-ping" />
                  <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
                </span>
                {busy ? 'يكتب الآن…' : 'جاهز للدردشة'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              aria-label="تبديل السمة"
              className="size-9"
            >
              {mounted && theme === 'dark' ? (
                <Sun className="size-4.5" />
              ) : (
                <Moon className="size-4.5" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onNewChat}
              aria-label="محادثة جديدة"
              className="size-9 text-muted-foreground hover:text-destructive"
              disabled={!hasMessages && !busy}
            >
              <Trash2 className="size-4.5" />
            </Button>
          </div>
        </header>

        {/* Messages */}
        <main
          ref={scrollRef}
          className="zaza-scroll flex-1 overflow-y-auto"
        >
          {!hasMessages ? (
            <WelcomeScreen onPick={(p) => submit(p)} />
          ) : (
            <div className="max-w-3xl mx-auto py-5 sm:py-7 space-y-5">
              {messages.map((m) => (
                <MessageBubble key={m.id} message={m} />
              ))}
              <div ref={bottomRef} className="h-1" />
            </div>
          )}
        </main>

        {/* Input area */}
        <footer className="border-t border-border bg-background/80 backdrop-blur-md px-3 sm:px-5 py-3">
          <div className="max-w-3xl mx-auto">
            <div className="relative flex items-end gap-2 rounded-2xl border border-border bg-card focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-primary/20 transition-all p-1.5">
              <Textarea
                ref={taRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={onKey}
                rows={1}
                placeholder="اكتب رسالتك إلى Zaza Al…  (Enter للإرسال، Shift+Enter لسطر جديد)"
                className="flex-1 resize-none bg-transparent border-0 focus-visible:ring-0 focus-visible:ring-offset-0 min-h-[44px] max-h-[200px] px-3 py-2.5 text-[15px] leading-relaxed"
                disabled={busy && !input}
              />
              {busy ? (
                <Button
                  onClick={stop}
                  size="icon"
                  variant="destructive"
                  className="size-10 rounded-xl flex-shrink-0"
                  aria-label="إيقاف"
                >
                  <Square className="size-4 fill-current" />
                </Button>
              ) : (
                <Button
                  onClick={() => submit(input)}
                  size="icon"
                  className="size-10 rounded-xl flex-shrink-0"
                  disabled={!input.trim()}
                  aria-label="إرسال"
                >
                  <Send className="size-4 rtl:-scale-x-100" />
                </Button>
              )}
            </div>
            <p className="text-[11px] text-muted-foreground text-center mt-2 flex items-center justify-center gap-1">
              <Heart className="size-3 inline" />
              Zaza Al قد يخطئ أحيانًا — تحقّق من المعلومات المهمة.
            </p>
          </div>
        </footer>
      </div>
    </div>
  )
}
