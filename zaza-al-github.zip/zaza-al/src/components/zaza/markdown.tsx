'use client'

import * as React from 'react'
import ReactMarkdown from 'react-markdown'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'
import { Check, Copy } from 'lucide-react'

interface ZazaMarkdownProps {
  content: string
}

function CodeBlock({ language, value }: { language: string; value: string }) {
  const [copied, setCopied] = React.useState(false)

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(value)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="relative group my-3" dir="ltr">
      <div className="flex items-center justify-between px-3 py-1.5 bg-muted/80 rounded-t-md border border-b-0 border-border">
        <span className="text-[11px] font-mono text-muted-foreground uppercase tracking-wide">
          {language || 'code'}
        </span>
        <button
          onClick={onCopy}
          className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1 text-[11px]"
          aria-label="نسخ الكود"
        >
          {copied ? (
            <>
              <Check className="size-3.5" /> تم النسخ
            </>
          ) : (
            <>
              <Copy className="size-3.5" /> نسخ
            </>
          )}
        </button>
      </div>
      <SyntaxHighlighter
        language={language || 'text'}
        style={oneDark}
        customStyle={{
          margin: 0,
          borderRadius: '0 0 0.625rem 0.625rem',
          fontSize: '0.85em',
          padding: '0.85em 1em',
        }}
        showLineNumbers={false}
        wrapLongLines
      >
        {value}
      </SyntaxHighlighter>
    </div>
  )
}

export function ZazaMarkdown({ content }: ZazaMarkdownProps) {
  return (
    <div className="zaza-md">
      <ReactMarkdown
        components={{
          code({ className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || '')
            const value = String(children ?? '').replace(/\n$/, '')
            const isInline = !className && !value.includes('\n')

            if (isInline) {
              return (
                <code className={className} {...props}>
                  {children}
                </code>
              )
            }

            return (
              <CodeBlock
                language={match?.[1] ?? ''}
                value={value}
              />
            )
          },
          pre({ children }) {
            // The CodeBlock already wraps in <pre>, so just pass through
            return <>{children}</>
          },
          a({ href, children }) {
            return (
              <a href={href} target="_blank" rel="noopener noreferrer">
                {children}
              </a>
            )
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  )
}
