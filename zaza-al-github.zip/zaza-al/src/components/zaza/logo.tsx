'use client'

import * as React from 'react'

interface ZazaLogoProps {
  size?: number
  className?: string
  animated?: boolean
}

/**
 * Zaza Al logo — a friendly glowing orb with an "Z" sigil.
 * Pure SVG, no external assets.
 */
export function ZazaLogo({ size = 40, className = '', animated = true }: ZazaLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="Zaza Al"
    >
      <defs>
        <linearGradient id="zaza-grad-main" x1="0" y1="0" x2="64" y2="64">
          <stop offset="0%" stopColor="oklch(0.75 0.24 295)" />
          <stop offset="50%" stopColor="oklch(0.7 0.22 320)" />
          <stop offset="100%" stopColor="oklch(0.75 0.18 165)" />
        </linearGradient>
        <radialGradient id="zaza-grad-glow" cx="50%" cy="40%" r="60%">
          <stop offset="0%" stopColor="oklch(0.95 0.05 295)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="oklch(0.7 0.24 295)" stopOpacity="0" />
        </radialGradient>
        {animated && (
          <>
            <animate
              href="#zaza-orb"
              attributeName="opacity"
              values="0.95;1;0.95"
              dur="3s"
              repeatCount="indefinite"
            />
          </>
        )}
      </defs>

      {/* Glow halo */}
      <circle cx="32" cy="32" r="30" fill="url(#zaza-grad-glow)" opacity="0.5" />

      {/* Main orb */}
      <g id="zaza-orb">
        <circle cx="32" cy="32" r="22" fill="url(#zaza-grad-main)" />
        <circle
          cx="32"
          cy="32"
          r="22"
          fill="none"
          stroke="oklch(0.95 0.05 295)"
          strokeOpacity="0.4"
          strokeWidth="1"
        />
        {/* Z sigil */}
        <path
          d="M 23 24 H 41 L 25 40 H 41"
          stroke="white"
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        {/* Sparkle */}
        <circle cx="44" cy="20" r="2.2" fill="white" opacity="0.85">
          {animated && (
            <animate
              attributeName="opacity"
              values="0.4;1;0.4"
              dur="2s"
              repeatCount="indefinite"
            />
          )}
        </circle>
      </g>
    </svg>
  )
}
